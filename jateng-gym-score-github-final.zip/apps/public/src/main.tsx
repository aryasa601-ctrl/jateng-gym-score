import React,{useEffect,useMemo,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {createClient} from '@supabase/supabase-js';
import type {PublicResult,Apparatus} from '@jateng-gym/shared';
import {APPARATUS_BY_GENDER} from '@jateng-gym/shared';
import './style.css';

const url=import.meta.env.VITE_SUPABASE_URL as string|undefined;
const key=import.meta.env.VITE_SUPABASE_ANON_KEY as string|undefined;
const supabase=url&&key?createClient(url,key):null;
const allApparatus=Array.from(new Set(Object.values(APPARATUS_BY_GENDER).flat())) as Apparatus[];
const fmt=(n:number)=>Number(n).toFixed(3);

function App(){
 const [results,setResults]=useState<PublicResult[]>([]); const [cat,setCat]=useState('all'); const [featuredSetting,setFeaturedSetting]=useState<any>(null); const [apparatus,setApparatus]=useState('all');
 const [connected,setConnected]=useState(true); const [tv,setTv]=useState(false); const [rotation,setRotation]=useState(true); const [rotIndex,setRotIndex]=useState(0); const [flash,setFlash]=useState(false);
 const load=async()=>{ if(!supabase)return; const [{data,error},{data:setting}]=await Promise.all([supabase.rpc('public_results_v2'),supabase.rpc('get_competition_settings_v2')]); if(!error)setResults((data||[]) as PublicResult[]); else setConnected(false); setFeaturedSetting(setting?.[0]||null); };
 useEffect(()=>{load(); if(!supabase)return; const ch=supabase.channel('public-score-events').on('postgres_changes',{event:'INSERT',schema:'public',table:'score_events'},()=>{setFlash(true);setTimeout(()=>setFlash(false),1200);load();}).subscribe(s=>setConnected(s==='SUBSCRIBED')); return()=>{supabase.removeChannel(ch)}},[]);
 const categories=useMemo(()=>Array.from(new Map(results.map(r=>[r.category_name,{id:r.category_name,name:r.category_name}])).values()),[results]);
 const filtered=useMemo(()=>results.filter(r=>(cat==='all'||r.category_name===cat)&&(apparatus==='all'||r.apparatus===apparatus)),[results,cat,apparatus]);
 const apparatusGroups=useMemo(()=>Array.from(new Set(filtered.map(r=>r.apparatus))),[filtered]);
 const rankRows=(rows:PublicResult[])=>{const sorted=[...rows].sort((a,b)=>b.total-a.total||b.e_final-a.e_final||b.d-a.d||a.name.localeCompare(b.name));let prev:string|undefined;let rank=0;return sorted.map((r,i)=>{const k=`${r.total}|${r.e_final}|${r.d}`;if(k!==prev)rank=i+1;prev=k;return {...r,rank};});};
 const grouped=useMemo(()=>Array.from(new Set(filtered.map(r=>r.apparatus))).map(a=>[a,rankRows(filtered.filter(r=>r.apparatus===a))] as const),[filtered]);
 const rankings=useMemo(()=>apparatus==='all'?grouped.flatMap(x=>x[1]):rankRows(filtered),[apparatus,grouped,filtered]);
 const allAround=useMemo(()=>{
   const map=new Map<string,PublicResult[]>();
   results.filter(r=>cat==='all'||r.category_name===cat).forEach(r=>map.set(r.athlete_id,[...(map.get(r.athlete_id)||[]),r]));
   const rows=Array.from(map.values()).map(rs=>{const total=rs.reduce((s,r)=>s+r.total,0); return {...rs[0],total,apparatus_count:rs.length,e_final:rs.reduce((s,r)=>s+r.e_final,0),d:rs.reduce((s,r)=>s+r.d,0)}}).sort((a,b)=>b.total-a.total||b.e_final-a.e_final||b.d-a.d);
   return rows.map((r,i)=>{const prev=rows[i-1]; const same=!!prev&&prev.total===r.total&&prev.e_final===r.e_final&&prev.d===r.d; return {...r,rank:same?prev.rank:i+1};});
 },[results,cat]);
 const featured=results.length?results.reduce((a,b)=>(new Date(a.updated_at||0).getTime()>new Date(b.updated_at||0).getTime()?a:b)):null;
 useEffect(()=>{if(!tv||!rotation||apparatusGroups.length<2)return;const t=setInterval(()=>setRotIndex(i=>(i+1)%apparatusGroups.length),10000);return()=>clearInterval(t)},[tv,rotation,apparatusGroups.length]);
 const tvRows=useMemo(()=>{if(!tv||apparatusGroups.length===0)return rankings; const ap=apparatusGroups[rotIndex%apparatusGroups.length]; return rankings.filter(r=>r.apparatus===ap)},[tv,rankings,apparatusGroups,rotIndex]);
 if(!url||!key)return <div className="center"><h1>Konfigurasi belum lengkap</h1><p>Isi VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY pada deployment situs publik.</p></div>;
 return <main className={tv?'tv':''}>
   <header className="topbar"><div><div className="eyebrow">KEJUARAAN SENAM ARTISTIK</div><h1>Jawa Tengah</h1></div><div className="actions"><span className={connected?'status on':'status'}>{connected?'● Langsung':'● Terputus'}</span><button onClick={()=>setTv(!tv)}>{tv?'Keluar Mode TV':'Mode TV'}</button></div></header>
   {featured&&<section className={'hero '+(flash?'flash':'')}><div><span className="eyebrow">HASIL TERBARU</span><h2>{featured.name}</h2><p>{featured.club} · {featured.category_name}</p><p className="hero-apparatus">{featured.apparatus}</p></div><div className="score-grid"><div><small>D</small><b>{fmt(featured.d)}</b></div><div><small>E AKHIR</small><b>{fmt(featured.e_final)}</b></div><div className="total"><small>TOTAL</small><b>{fmt(featured.total)}</b></div></div></section>}
   {!featured&&<section className="empty"><h2>Menunggu nilai pertama</h2><p>Hasil akan muncul otomatis setelah empat nilai juri lengkap.</p></section>}
   <section className="filters"><select value={cat} onChange={e=>setCat(e.target.value)}><option value="all">Semua kategori</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select><select value={apparatus} onChange={e=>setApparatus(e.target.value)}><option value="all">Semua alat</option>{allApparatus.map(a=><option key={a}>{a}</option>)}</select><label><input type="checkbox" checked={rotation} onChange={e=>setRotation(e.target.checked)}/> Rotasi alat 10 detik</label></section>
   {(featuredSetting?.featured_athlete_name||featuredSetting?.featured_apparatus)&&<div className="tv-caption">Sedang tampil: {featuredSetting?.featured_athlete_name||'—'} di {featuredSetting?.featured_apparatus||'—'}</div>}{tv&&<div className="tv-caption">Sedang tampil otomatis: {tvRows[0]?.name||'—'} di {tvRows[0]?.apparatus||'—'}</div>}
   <section className="board"><div className="board-title"><h2>{tv&&apparatusGroups.length?apparatusGroups[rotIndex%apparatusGroups.length]:'Papan Peringkat'}</h2><span>{tv?'Mode TV':'Real-time'}</span></div>{(tv?[['',tvRows] as const]:apparatus==='all'?grouped:([[apparatus,rankings]] as const)).map(([ap,rows])=><div key={ap} className="table-wrap"><div className="section-label">{ap}</div><table><thead><tr><th>Rank</th><th>Atlet</th><th>Klub/Kota</th><th>Kategori</th><th>Alat</th><th>D</th><th>E Akhir</th><th>Total</th></tr></thead><tbody>{rows.map((r,i)=><tr key={`${r.name}-${r.club}-${r.apparatus}`} className={i<3?'podium':''}><td><strong>{r.rank}</strong></td><td className="name">{r.name}</td><td>{r.club}</td><td>{r.category_name}</td><td>{r.apparatus}</td><td>{fmt(r.d)}</td><td>{fmt(r.e_final)}</td><td><b>{fmt(r.total)}</b></td></tr>)}</tbody></table></div>)}{!rankings.length&&<div className="empty small">Menunggu nilai pertama</div>}</section>
   <section className="board"><div className="board-title"><h2>All-Around</h2><span>Jumlah alat selesai</span></div><div className="table-wrap"><table><thead><tr><th>Rank</th><th>Atlet</th><th>Klub/Kota</th><th>Kategori</th><th>Jumlah alat</th><th>Total</th></tr></thead><tbody>{allAround.map(r=><tr key={r.athlete_id}><td><strong>{r.rank}</strong></td><td className="name">{r.name}</td><td>{r.club}</td><td>{r.category_name}</td><td>{r.apparatus_count}</td><td><b>{fmt(r.total)}</b></td></tr>)}</tbody></table></div></section>
   <footer>Kejuaraan Senam Artistik · Zona waktu WIB</footer>
 </main>
}
createRoot(document.getElementById('root')!).render(<App/>);
