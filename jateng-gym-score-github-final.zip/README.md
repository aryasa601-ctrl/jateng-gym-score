# Jateng Gym Score

Papan skor digital kejuaraan Senam Artistik Jawa Tengah: situs publik tanpa login + situs juri/admin terpisah, satu Supabase.

## Struktur
- `apps/public` — deployment publik/TV.
- `apps/judge` — deployment juri (`/j/[TOKEN]`) dan admin (`/admin`).
- `shared` — rumus, tipe, daftar alat.
- `supabase/schema.sql` — database, RLS, RPC, audit, realtime.
- `supabase/seed_demo.sql` — data demo.

## Aturan skor
D + rata-rata(E1,E2,E3), tanpa penalti. Pembulatan 3 desimal hanya pada hasil akhir. Seri: E akhir > D > peringkat sama dengan nomor berikutnya melompat.


## Versi yang sudah dilanjutkan
- Scan QR/link juri baru selalu mengambil token dari URL, sehingga tidak tertahan token lama di perangkat.
- Panel juri menerima refresh status atlet secara realtime melalui `score_events` tanpa membuka nilai juri lain.
- Atlet/kategori yang dikunci tampil nonaktif di panel juri.
- Hasil publik memakai `public_results_v2()` agar ID atlet tersedia untuk agregasi All-Around; RPC `public_results()` lama tetap dipertahankan untuk kompatibilitas.
- Pengaturan featured publik memakai `get_competition_settings_v2()`; fungsi lama tetap tersedia.
- Koreksi nilai oleh admin juga divalidasi untuk batas desimal, batas nilai E, dan kesesuaian alat dengan gender atlet.
