-- Demo data. Jalankan setelah schema.sql. Hapus kapan saja dengan: delete from public.athletes; delete from public.categories;
insert into public.categories(id,name,gender,age_group) values
('00000000-0000-0000-0000-000000000001','Putra Junior','Putra','Junior'),
('00000000-0000-0000-0000-000000000002','Putri Senior','Putri','Senior')
on conflict(id) do nothing;
insert into public.athletes(id,name,club,category_id) values
('10000000-0000-0000-0000-000000000001','Bima Pratama','Kota Semarang','00000000-0000-0000-0000-000000000001'),
('10000000-0000-0000-0000-000000000002','Alya Maharani','Kabupaten Kendal','00000000-0000-0000-0000-000000000002'),
('10000000-0000-0000-0000-000000000003','Raka Wijaya','Kota Salatiga','00000000-0000-0000-0000-000000000001')
on conflict(id) do nothing;
insert into public.scores(athlete_id,apparatus,role,value) values
('10000000-0000-0000-0000-000000000001','Lantai','D',5.200),
('10000000-0000-0000-0000-000000000001','Lantai','E1',8.500),
('10000000-0000-0000-0000-000000000001','Lantai','E2',8.700),
('10000000-0000-0000-0000-000000000001','Lantai','E3',8.600)
on conflict(athlete_id,apparatus,role) do update set value=excluded.value;
