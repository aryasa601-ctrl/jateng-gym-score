-- Jalankan dari SQL Editor sebagai pengujian struktural/admin. Untuk pengujian anonim, gunakan REST API dengan anon key setelah deployment.
-- 1) Anon tidak memiliki SELECT/INSERT/UPDATE/DELETE policy pada tabel scores, judge_tokens, athletes, categories, audit_log.
-- 2) submit_score adalah satu-satunya grant INSERT/UPDATE path untuk anonim dan memvalidasi role dari token hash.
-- 3) get_judge_context hanya mengembalikan my_value milik token, bukan angka juri lain.
-- 4) public_results hanya mengembalikan grup yang memiliki tepat empat peran.
select n.nspname, c.relname, has_table_privilege('anon',c.oid,'insert') as anon_insert, has_table_privilege('anon',c.oid,'update') as anon_update, has_table_privilege('anon',c.oid,'delete') as anon_delete
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname in ('scores','judge_tokens','athletes','categories','audit_log');
