-- Gymnastics Artistic Scoreboard — Supabase schema
create extension if not exists pgcrypto;

create type public.gender_type as enum ('Putra','Putri');
create type public.judge_role as enum ('D','E1','E2','E3');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'admin' check (role='admin'),
  created_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  gender public.gender_type not null,
  age_group text not null,
  created_at timestamptz not null default now()
);

create table public.athletes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  club text not null,
  category_id uuid not null references public.categories(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.judge_tokens (
  id uuid primary key default gen_random_uuid(),
  role public.judge_role not null,
  token_hash text not null unique,
  revoked boolean not null default false,
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);

create unique index judge_one_active_per_role on public.judge_tokens(role) where revoked=false;

create table public.score_locks (
  athlete_id uuid references public.athletes(id) on delete cascade,
  apparatus text,
  category_id uuid references public.categories(id) on delete cascade,
  locked boolean not null default true,
  updated_at timestamptz not null default now(),
  check ((athlete_id is not null and apparatus is not null and category_id is null) or (athlete_id is null and apparatus is null and category_id is not null)),
  unique (athlete_id, apparatus),
  unique (category_id)
);

create table public.scores (
  id uuid primary key default gen_random_uuid(),
  athlete_id uuid not null references public.athletes(id) on delete cascade,
  apparatus text not null,
  role public.judge_role not null,
  value numeric(12,3) not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id),
  unique (athlete_id, apparatus, role)
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_role text not null,
  actor_id uuid,
  athlete_id uuid references public.athletes(id) on delete set null,
  apparatus text,
  judge_role public.judge_role,
  old_value numeric(12,3),
  new_value numeric(12,3),
  action text not null,
  created_at timestamptz not null default now()
);

create table public.score_events (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now()
);

create table public.competition_settings (
  id boolean primary key default true check (id=true),
  featured_athlete_id uuid references public.athletes(id) on delete set null,
  featured_apparatus text,
  rotation_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);
insert into public.competition_settings(id) values(true) on conflict do nothing;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end; $$;
create trigger athletes_touch before update on public.athletes for each row execute function public.touch_updated_at();

-- Base tables are never writable/readable by anonymous users.
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.athletes enable row level security;
alter table public.judge_tokens enable row level security;
alter table public.score_locks enable row level security;
alter table public.scores enable row level security;
alter table public.audit_log enable row level security;
alter table public.score_events enable row level security;
alter table public.competition_settings enable row level security;

create policy profiles_admin_all on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy categories_admin_all on public.categories for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy athletes_admin_all on public.athletes for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy judge_tokens_admin_all on public.judge_tokens for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy score_locks_admin_all on public.score_locks for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy scores_admin_all on public.scores for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy audit_admin_read on public.audit_log for select to authenticated using (public.is_admin());
create policy events_public_read on public.score_events for select to anon, authenticated using (true);
create policy settings_admin_all on public.competition_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Realtime publication: events are intentionally the only anonymous realtime surface.
alter publication supabase_realtime add table public.score_events;

create or replace function public.hash_token(raw_token text)
returns text language sql immutable as $$ select encode(digest(raw_token,'sha256'),'hex'); $$;

create or replace function public.create_judge_token(p_role public.judge_role)
returns table(role public.judge_role, token text)
language plpgsql security definer set search_path=public
as $$
declare v_token text;
begin
  if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
  update public.judge_tokens set revoked=true, revoked_at=now() where judge_tokens.role=p_role and revoked=false;
  v_token=encode(gen_random_bytes(32),'hex');
  insert into public.judge_tokens(role, token_hash) values(p_role, public.hash_token(v_token));
  return query select p_role, v_token;
end; $$;
revoke all on function public.create_judge_token(public.judge_role) from public;
grant execute on function public.create_judge_token(public.judge_role) to authenticated;

create or replace function public.revoke_judge_role(p_role public.judge_role)
returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
 update public.judge_tokens set revoked=true, revoked_at=now() where role=p_role and revoked=false;
end; $$;
revoke all on function public.revoke_judge_role(public.judge_role) from public;
grant execute on function public.revoke_judge_role(public.judge_role) to authenticated;

create or replace function public.get_judge_role(p_token text)
returns public.judge_role language sql security definer set search_path=public as $$ select role from judge_tokens where token_hash=public.hash_token(p_token) and revoked=false limit 1; $$;
grant execute on function public.get_judge_role(text) to anon,authenticated;

create or replace function public.get_judge_context(p_token text, p_apparatus text)
returns table(athlete_id uuid,name text,club text,category_id uuid,category_name text,gender public.gender_type,d_done boolean,e1_done boolean,e2_done boolean,e3_done boolean,my_value numeric,locked boolean)
language plpgsql security definer set search_path=public as $$
declare v_role public.judge_role; v_token_id uuid;
begin
 select jt.role,jt.id into v_role,v_token_id from public.judge_tokens jt where jt.token_hash=public.hash_token(p_token) and jt.revoked=false limit 1;
 if v_role is null then raise exception 'INVALID_TOKEN'; end if;
 return query
 select a.id,a.name,a.club,c.id,c.name,c.gender,
   exists(select 1 from scores s where s.athlete_id=a.id and s.apparatus=p_apparatus and s.role='D'),
   exists(select 1 from scores s where s.athlete_id=a.id and s.apparatus=p_apparatus and s.role='E1'),
   exists(select 1 from scores s where s.athlete_id=a.id and s.apparatus=p_apparatus and s.role='E2'),
   exists(select 1 from scores s where s.athlete_id=a.id and s.apparatus=p_apparatus and s.role='E3'),
   (select s.value from scores s where s.athlete_id=a.id and s.apparatus=p_apparatus and s.role=v_role),
   coalesce((select sl.locked from score_locks sl where sl.athlete_id=a.id and sl.apparatus=p_apparatus),false) or coalesce((select sl.locked from score_locks sl where sl.category_id=c.id),false)
 from athletes a join categories c on c.id=a.category_id
 where p_apparatus = any(case when c.gender='Putra' then array['Lantai','Kuda Pelana','Cincin','Lompat Meja','Palang Sejajar','Palang Tunggal'] else array['Lompat Meja','Palang Bertingkat','Balok Keseimbangan','Lantai'] end)
 order by a.name;
end; $$;
grant execute on function public.get_judge_context(text,text) to anon,authenticated;

create or replace function public.submit_score(p_token text,p_athlete_id uuid,p_apparatus text,p_value numeric)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_role public.judge_role; v_token_id uuid; v_old numeric; v_locked boolean; v_category uuid; v_count int; v_gender public.gender_type;
begin
 select jt.role,jt.id into v_role,v_token_id from public.judge_tokens jt where jt.token_hash=public.hash_token(p_token) and jt.revoked=false for update;
 if v_role is null then raise exception 'INVALID_TOKEN'; end if;
 if p_value is null or p_value < 0 then raise exception 'INVALID_VALUE'; end if;
 if v_role <> 'D' and p_value > 10 then raise exception 'INVALID_VALUE'; end if;
 if p_value <> round(p_value,3) then raise exception 'MAX_3_DECIMALS'; end if;
 select a.category_id,c.gender into v_category,v_gender from athletes a join categories c on c.id=a.category_id where a.id=p_athlete_id;
 if v_category is null then raise exception 'ATHLETE_NOT_FOUND'; end if;
 if not (p_apparatus = any(case when v_gender='Putra' then array['Lantai','Kuda Pelana','Cincin','Lompat Meja','Palang Sejajar','Palang Tunggal'] else array['Lompat Meja','Palang Bertingkat','Balok Keseimbangan','Lantai'] end)) then raise exception 'APPARATUS_NOT_ALLOWED'; end if;
 select coalesce((select sl.locked from score_locks sl where sl.athlete_id=p_athlete_id and sl.apparatus=p_apparatus),false) or coalesce((select sl.locked from score_locks sl where sl.category_id=v_category),false) into v_locked;
 if v_locked then raise exception 'LOCKED'; end if;
 select count(*) into v_count from audit_log where actor_id=v_token_id and created_at > now()-interval '1 minute';
 if v_count >= 30 then raise exception 'RATE_LIMIT'; end if;
 select value into v_old from scores where athlete_id=p_athlete_id and apparatus=p_apparatus and role=v_role;
 insert into scores(athlete_id,apparatus,role,value,updated_by) values(p_athlete_id,p_apparatus,v_role,p_value,null)
 on conflict(athlete_id,apparatus,role) do update set value=excluded.value,updated_at=now();
 insert into audit_log(actor_role,actor_id,athlete_id,apparatus,judge_role,old_value,new_value,action) values(v_role::text,v_token_id,p_athlete_id,p_apparatus,v_role,v_old,p_value,case when v_old is null then 'submit' else 'correct' end);
 return jsonb_build_object('ok',true,'role',v_role,'old_value',v_old,'new_value',p_value);
end; $$;
revoke all on function public.submit_score(text,uuid,text,numeric) from public;
grant execute on function public.submit_score(text,uuid,text,numeric) to anon,authenticated;

create or replace function public.public_results()
returns table(name text,club text,category_name text,apparatus text,d numeric,e_final numeric,total numeric,updated_at timestamptz)
language sql security definer set search_path=public as $$
 select a.name,a.club,c.name,s.apparatus,
   max(s.value) filter(where s.role='D') as d,
   round(((max(s.value) filter(where s.role='E1'))+(max(s.value) filter(where s.role='E2'))+(max(s.value) filter(where s.role='E3')))/3,3) as e_final,
   round((max(s.value) filter(where s.role='D'))+(((max(s.value) filter(where s.role='E1'))+(max(s.value) filter(where s.role='E2'))+(max(s.value) filter(where s.role='E3')))/3),3) as total, max(s.updated_at) as updated_at
 from scores s join athletes a on a.id=s.athlete_id join categories c on c.id=a.category_id
 group by a.id,a.name,a.club,c.id,c.name,c.gender,s.apparatus
 having count(*) filter(where s.role in ('D','E1','E2','E3'))=4;
$$;
grant execute on function public.public_results() to anon,authenticated;


-- Versioned result RPC with athlete_id for richer client-side aggregation. The original
-- public_results() signature is kept intact for backward compatibility.
create or replace function public.public_results_v2()
returns table(athlete_id uuid,name text,club text,category_name text,apparatus text,d numeric,e_final numeric,total numeric,updated_at timestamptz)
language sql security definer set search_path=public as $$
 select a.id,a.name,a.club,c.name,s.apparatus,
   max(s.value) filter(where s.role='D') as d,
   round(((max(s.value) filter(where s.role='E1'))+(max(s.value) filter(where s.role='E2'))+(max(s.value) filter(where s.role='E3')))/3,3) as e_final,
   round((max(s.value) filter(where s.role='D'))+(((max(s.value) filter(where s.role='E1'))+(max(s.value) filter(where s.role='E2'))+(max(s.value) filter(where s.role='E3')))/3),3) as total, max(s.updated_at) as updated_at
 from scores s join athletes a on a.id=s.athlete_id join categories c on c.id=a.category_id
 group by a.id,a.name,a.club,c.id,c.name,c.gender,s.apparatus
 having count(*) filter(where s.role in ('D','E1','E2','E3'))=4;
$$;
grant execute on function public.public_results_v2() to anon,authenticated;

create or replace function public.admin_set_lock(p_athlete_id uuid,p_apparatus text,p_locked boolean)
returns void language plpgsql security definer set search_path=public as $$
begin if not public.is_admin() then raise exception 'FORBIDDEN'; end if; insert into score_locks(athlete_id,apparatus,locked) values(p_athlete_id,p_apparatus,p_locked) on conflict(athlete_id,apparatus) do update set locked=p_locked,updated_at=now(); end; $$;
grant execute on function public.admin_set_lock(uuid,text,boolean) to authenticated;

create or replace function public.admin_set_category_lock(p_category_id uuid,p_locked boolean)
returns void language plpgsql security definer set search_path=public as $$
begin if not public.is_admin() then raise exception 'FORBIDDEN'; end if; insert into score_locks(category_id,locked) values(p_category_id,p_locked) on conflict(category_id) do update set locked=p_locked,updated_at=now(); end; $$;
grant execute on function public.admin_set_category_lock(uuid,boolean) to authenticated;

create or replace function public.admin_upsert_score(p_athlete_id uuid,p_apparatus text,p_role public.judge_role,p_value numeric)
returns void language plpgsql security definer set search_path=public as $$
declare v_old numeric; v_gender public.gender_type;
begin
 if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
 if p_value is null or p_value < 0 or p_value <> round(p_value,3) then raise exception 'INVALID_VALUE'; end if;
 if p_role <> 'D' and p_value > 10 then raise exception 'INVALID_VALUE'; end if;
 select c.gender into v_gender from athletes a join categories c on c.id=a.category_id where a.id=p_athlete_id;
 if v_gender is null then raise exception 'ATHLETE_NOT_FOUND'; end if;
 if not (p_apparatus = any(case when v_gender='Putra' then array['Lantai','Kuda Pelana','Cincin','Lompat Meja','Palang Sejajar','Palang Tunggal'] else array['Lompat Meja','Palang Bertingkat','Balok Keseimbangan','Lantai'] end)) then raise exception 'APPARATUS_NOT_ALLOWED'; end if;
 select value into v_old from scores where athlete_id=p_athlete_id and apparatus=p_apparatus and role=p_role;
 insert into scores(athlete_id,apparatus,role,value,updated_by) values(p_athlete_id,p_apparatus,p_role,p_value,auth.uid())
 on conflict(athlete_id,apparatus,role) do update set value=excluded.value,updated_at=now(),updated_by=auth.uid();
 insert into audit_log(actor_role,actor_id,athlete_id,apparatus,judge_role,old_value,new_value,action) values('admin',auth.uid(),p_athlete_id,p_apparatus,p_role,v_old,p_value,'admin_correction');
end; $$;
grant execute on function public.admin_upsert_score(uuid,text,public.judge_role,numeric) to authenticated;

create or replace function public.admin_delete_score(p_athlete_id uuid,p_apparatus text,p_role public.judge_role)
returns void language plpgsql security definer set search_path=public as $$
declare v_old numeric;
begin if not public.is_admin() then raise exception 'FORBIDDEN'; end if; select value into v_old from scores where athlete_id=p_athlete_id and apparatus=p_apparatus and role=p_role; delete from scores where athlete_id=p_athlete_id and apparatus=p_apparatus and role=p_role; insert into audit_log(actor_role,actor_id,athlete_id,apparatus,judge_role,old_value,new_value,action) values('admin',auth.uid(),p_athlete_id,p_apparatus,p_role,v_old,null,'admin_delete'); end; $$;
grant execute on function public.admin_delete_score(uuid,text,public.judge_role) to authenticated;

create or replace function public.admin_reset_competition()
returns void language plpgsql security definer set search_path=public as $$
begin if not public.is_admin() then raise exception 'FORBIDDEN'; end if; delete from audit_log; delete from scores; delete from score_locks; delete from score_events; end; $$;
grant execute on function public.admin_reset_competition() to authenticated;

create or replace function public.refresh_score_event()
returns trigger language plpgsql security definer set search_path=public as $$
declare n int; v_athlete uuid; v_apparatus text; begin v_athlete:=coalesce(new.athlete_id,old.athlete_id); v_apparatus:=coalesce(new.apparatus,old.apparatus); select count(*) into n from scores where athlete_id=v_athlete and apparatus=v_apparatus; if (tg_op='DELETE' and n=3) or (tg_op<>'DELETE' and n=4) then insert into score_events default values; end if; return coalesce(new,old); end; $$;
create trigger scores_event after insert or update or delete on public.scores for each row execute function public.refresh_score_event();

create or replace function public.get_competition_settings()
returns table(featured_athlete_name text,featured_apparatus text,rotation_enabled boolean)
language sql security definer set search_path=public as $$ select a.name,cs.featured_apparatus,cs.rotation_enabled from competition_settings cs left join athletes a on a.id=cs.featured_athlete_id where cs.id=true; $$;
grant execute on function public.get_competition_settings() to anon,authenticated;

create or replace function public.get_competition_settings_v2()
returns table(featured_athlete_id uuid,featured_athlete_name text,featured_apparatus text,rotation_enabled boolean)
language sql security definer set search_path=public as $$ select cs.featured_athlete_id,a.name,cs.featured_apparatus,cs.rotation_enabled from competition_settings cs left join athletes a on a.id=cs.featured_athlete_id where cs.id=true; $$;
grant execute on function public.get_competition_settings_v2() to anon,authenticated;

create or replace function public.admin_set_featured(p_athlete_id uuid,p_apparatus text,p_rotation boolean)
returns void language plpgsql security definer set search_path=public as $$ begin if not public.is_admin() then raise exception 'FORBIDDEN'; end if; update competition_settings set featured_athlete_id=p_athlete_id,featured_apparatus=p_apparatus,rotation_enabled=p_rotation,updated_at=now() where id=true; end; $$;
grant execute on function public.admin_set_featured(uuid,text,boolean) to authenticated;
