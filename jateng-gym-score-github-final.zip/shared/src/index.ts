export type JudgeRole = 'D' | 'E1' | 'E2' | 'E3';
export type Gender = 'Putra' | 'Putri';
export type Apparatus =
  | 'Lantai' | 'Kuda Pelana' | 'Cincin' | 'Lompat Meja'
  | 'Palang Sejajar' | 'Palang Tunggal' | 'Palang Bertingkat' | 'Balok Keseimbangan';

export const APPARATUS_BY_GENDER: Record<Gender, Apparatus[]> = {
  Putra: ['Lantai','Kuda Pelana','Cincin','Lompat Meja','Palang Sejajar','Palang Tunggal'],
  Putri: ['Lompat Meja','Palang Bertingkat','Balok Keseimbangan','Lantai']
};

export const ROLES: JudgeRole[] = ['D','E1','E2','E3'];
export const ROLE_LABEL: Record<JudgeRole,string> = { D:'Juri D', E1:'Juri E1', E2:'Juri E2', E3:'Juri E3' };

export interface Category { id:string; name:string; gender:Gender; age_group:string; }
export interface Athlete { id:string; name:string; club:string; category_id:string; category?:Category; }
export interface PublicResult {
  athlete_id:string; name:string; club:string; category_id:string; category_name:string;
  gender:Gender; apparatus:Apparatus; d:number; e_final:number; total:number; updated_at?:string;
  apparatus_count?:number; rank?:number;
}

export const scoringRules = {
  eAverage(values:number[]) {
    if (values.length !== 3) throw new Error('Tiga nilai E diperlukan.');
    return (values[0] + values[1] + values[2]) / 3;
  },
  finalScore(d:number, eValues:number[]) {
    return round3(d + this.eAverage(eValues));
  },
  compare(a:{e_final:number; d:number}, b:{e_final:number; d:number}) {
    if (a.e_final !== b.e_final) return b.e_final - a.e_final;
    if (a.d !== b.d) return b.d - a.d;
    return 0;
  },
  rank(sorted:number[]) {
    const ranks:number[]=[]; let previous:number|undefined;
    sorted.forEach((_,i)=>{ const r=previous===undefined?1:sorted[i]===previous?ranks[i-1]:i+1; ranks.push(r); previous=sorted[i]; });
    return ranks;
  }
};
export function round3(n:number){ return Math.round((n + Number.EPSILON)*1000)/1000; }
export function normalizeDecimal(input:string){ return input.trim().replace(',', '.'); }
export function validateScore(role:JudgeRole, value:number){
  if (!Number.isFinite(value)) return 'Nilai harus berupa angka.';
  if (value < 0) return 'Nilai tidak boleh negatif.';
  if ((role !== 'D') && value > 10) return 'Nilai E maksimal 10.000.';
  if (!/^\d+(?:[.,]\d{1,3})?$/.test(String(value))) return 'Nilai maksimal 3 desimal.';
  return null;
}
