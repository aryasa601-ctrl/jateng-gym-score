# Upload ke GitHub

Repository tujuan: https://github.com/aryasa601-ctrl/jateng-gym-score

Upload seluruh isi ZIP ini ke root repository dan commit ke branch `main`.

## Deploy Netlify — Site Publik
- Base directory: `apps/public`
- Build command: `npm install && npm run build`
- Publish directory: `apps/public/dist`
- `VITE_SUPABASE_URL=https://xxixomadawbweahgdpzz.supabase.co`
- `VITE_SUPABASE_ANON_KEY=<publishable/anon key>`

## Deploy Netlify — Site Juri/Admin
- Base directory: `apps/judge`
- Build command: `npm install && npm run build`
- Publish directory: `apps/judge/dist`
- `VITE_SUPABASE_URL=https://xxixomadawbweahgdpzz.supabase.co`
- `VITE_SUPABASE_ANON_KEY=<publishable/anon key>`
- `VITE_PUBLIC_SITE_URL=<URL site publik Netlify>`

Jika Netlify workspace tidak menemukan dependency dari root, gunakan Base directory kosong dan build command:
`npm install && npm run build --workspace apps/public`
atau untuk site juri:
`npm install && npm run build --workspace apps/judge`.

## Supabase
Jalankan `supabase/schema.sql` di SQL Editor pada project Supabase sebelum menggunakan aplikasi.

## Keamanan
Jangan masukkan `service_role`/secret key ke GitHub atau frontend. Publishable/anon key memang dirancang untuk frontend dan tetap dilindungi oleh RLS di database.
