# Panduan Deploy Pemula

## 1. Buat Supabase
1. Buka Supabase dan buat project gratis.
2. Masuk SQL Editor, jalankan seluruh `supabase/schema.sql`.
3. Opsional: jalankan `supabase/seed_demo.sql` untuk data demo.
4. Authentication → Users → Add user, buat email/password admin.
5. SQL Editor jalankan:
   `insert into public.profiles(id,full_name,role) values ('UUID_USER','Nama Panitia','admin');`
   Ganti `UUID_USER` dengan UUID user dari halaman Users.
6. Settings → API, salin Project URL dan anon/publishable key.

## 2. Siapkan lokal
Prasyarat Node.js 20+.

```bash
npm install
```

Buat file `.env` di masing-masing app dari `.env.example`.

### Situs publik
`apps/public/.env`
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

### Situs juri/admin
`apps/judge/.env`
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_PUBLIC_SITE_URL=https://DOMAIN-PUBLIK-ANDA`

Jalankan:
```bash
npm run dev:public
npm run dev:judge
```

## 3. Deploy dua situs
### Netlify
Buat dua site dari repo yang sama.
- Site publik: Base directory `apps/public`, build command `npm install && npm run build`, publish `apps/public/dist`.
- Site juri: Base directory `apps/judge`, build command `npm install && npm run build`, publish `apps/judge/dist`.

Karena monorepo memakai workspace, jika dashboard Netlify tidak menjalankan root install, set Base directory kosong dan build command `npm install && npm run build --workspace apps/public` serta publish `apps/public/dist`. Untuk site juri ganti workspace-nya.

Masukkan environment variables pada masing-masing site.

## 4. Buat 4 link juri
1. Login `/admin` pada domain juri.
2. Buka tab **Link Juri**.
3. Klik **Buat ulang** untuk D, E1, E2, E3.
4. Token asli hanya ditampilkan saat itu. Simpan link/QR tersebut dan bagikan hanya ke juri terkait.
5. Jika bocor, klik **Buat ulang** pada peran tersebut. Token lama langsung dicabut di database.

## 5. QR publik
Di Dashboard admin, QR menuju `VITE_PUBLIC_SITE_URL` ditampilkan besar dan dapat dipindai/di-screenshot untuk dicetak. QR juri tersedia di hasil pembuatan link.

## 6. Operasional lomba
1. Buat kategori.
2. Tambah/import atlet dengan `category_id` yang benar.
3. Bagikan satu link rahasia ke masing-masing juri.
4. Juri memilih alat → atlet → nilai → konfirmasi kirim.
5. Publik hanya melihat hasil setelah D, E1, E2, E3 lengkap.
6. Admin dapat koreksi/hapus/kunci dan semua perubahan juri tercatat di audit.

## 7. Keamanan wajib
Jangan pernah memasukkan `service_role` key ke frontend. Hanya anon/publishable key yang boleh berada pada `.env` Vite. RLS dan RPC di `schema.sql` adalah pengaman utama.

## 8. Reset demo
Setelah uji coba, hapus data demo melalui SQL Editor atau gunakan tombol Reset kompetisi untuk menghapus skor/log/kunci tanpa menghapus atlet/kategori.
