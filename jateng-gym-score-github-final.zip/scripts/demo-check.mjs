const e=(8.5+8.7+8.6)/3; const total=Math.round((5.2+e)*1000)/1000;
if(e!==8.6||total!==13.8) throw new Error('Rumus demo gagal');
console.log('Demo rumus OK: E akhir 8.600, total 13.800');
