import fs from 'node:fs';
const schema=fs.readFileSync('supabase/schema.sql','utf8');
const pub=fs.readFileSync('apps/public/src/main.tsx','utf8');
const judge=fs.readFileSync('apps/judge/src/main.tsx','utf8');
const checks=[
 ['RLS scores enabled',schema.includes('alter table public.scores enable row level security')],
 ['No anon base score policy',!schema.includes('for insert to anon')&&!schema.includes('for update to anon')&&!schema.includes('for delete to anon')],
 ['Single submit RPC',schema.includes('create or replace function public.submit_score')],
 ['Token hash',schema.includes("digest(raw_token,'sha256')")],
 ['Role binding',schema.includes('v_role public.judge_role')&&schema.includes('jt.token_hash=public.hash_token(p_token)')],
 ['Complete-only public results',schema.includes("having count(*) filter(where s.role in ('D','E1','E2','E3'))=4")],
 ['E formula',schema.includes("(max(s.value) filter(where s.role='E1'))+(max(s.value) filter(where s.role='E2'))+(max(s.value) filter(where s.role='E3'))")],
 ['Public has no judge URL text',!pub.includes('/j/')],
 ['Judge noindex',fs.readFileSync('apps/judge/index.html','utf8').includes('noindex')],
 ['Referrer no-referrer',fs.readFileSync('apps/judge/index.html','utf8').includes('no-referrer')],
 ['Judge token removed from URL',judge.includes("history.replaceState")],
 ['Double-click prevention via confirm',judge.includes('confirm(`Kirim nilai')],
 ['Offline queue',judge.includes('localStorage.setItem(\'gym_queue\'' )],
 ['Token URL overrides stale local token',judge.includes('pathToken||localStorage.getItem')],
 ['Judge realtime refresh',judge.includes("table:'score_events'},()=>load()")],
 ['Locked athlete disabled',judge.includes('disabled={r.locked}')],
 ['Versioned public results RPC',schema.includes('public_results_v2')&&pub.includes("rpc(\'public_results_v2\')")],
 ['Legacy public results preserved',schema.includes('returns table(name text,club text,category_name text,apparatus text,d numeric,e_final numeric,total numeric,updated_at timestamptz)')],
 ['Versioned settings RPC',schema.includes('get_competition_settings_v2')&&pub.includes('get_competition_settings_v2')],
 ['Admin score validation',schema.includes("p_value <> round(p_value,3)")&&schema.includes('APPARATUS_NOT_ALLOWED')],
];
let ok=true; for(const [name,pass] of checks){console.log(`${pass?'PASS':'FAIL'} — ${name}`);if(!pass)ok=false}
const e=(8.5+8.7+8.6)/3, total=Math.round((5.2+e)*1000)/1000;
console.log(`PASS — Rumus contoh: E=${e.toFixed(3)}, total=${total.toFixed(3)}`);
if(e!==8.6||total!==13.8)ok=false;
process.exit(ok?0:1);
